<?php
/**
 * Deployment Verification Script
 * Run this after deployment to verify everything is working
 */

echo "=== MPSC Quiz Portal Deployment Verification ===\n";

// Check if files exist
$requiredFiles = [
    'quiz.php',
    'includes/functions.php',
    'TestQnA/general-english/vocabulary_synonyms.json',
    'TestQnA/general-english/categories_summary.json'
];

echo "Checking required files...\n";
foreach ($requiredFiles as $file) {
    if (file_exists($file)) {
        echo "✓ $file exists\n";
    } else {
        echo "✗ $file MISSING\n";
    }
}

// Test JSON loading
echo "\nTesting JSON data loading...\n";
if (file_exists('includes/functions.php')) {
    require_once 'includes/functions.php';
    
    $subcategories = get_testqna_subcategories('general-english');
    if (!empty($subcategories)) {
        echo "✓ JSON subcategories loaded: " . count($subcategories) . " found\n";
        echo "  Sample: " . $subcategories[0]['name'] . "\n";
    } else {
        echo "✗ Failed to load JSON subcategories\n";
    }
    
    $questions = load_questions_from_testqna('general-english', null, 3);
    if (!empty($questions)) {
        echo "✓ JSON questions loaded: " . count($questions) . " sample questions\n";
        echo "  Sample category: " . $questions[0]['category'] . "\n";
    } else {
        echo "✗ Failed to load JSON questions\n";
    }
} else {
    echo "✗ Cannot test - functions.php not found\n";
}

// Test database connection
echo "\nTesting database connection...\n";
if (file_exists('config/database.php')) {
    try {
        require_once 'config/database.php';
        $pdo = new PDO($dsn, $username, $password, $options);
        echo "✓ Database connection successful\n";
        
        // Check if migration was run
        $stmt = $pdo->query("SHOW TABLES LIKE 'migrations'");
        if ($stmt->rowCount() > 0) {
            $stmt = $pdo->query("SELECT * FROM migrations WHERE migration_name = 'json_general_english_migration'");
            if ($stmt->rowCount() > 0) {
                echo "✓ Database migration completed\n";
            } else {
                echo "⚠ Database migration not found - run database_migration.php\n";
            }
        } else {
            echo "⚠ Migrations table not found - run database_migration.php\n";
        }
    } catch (Exception $e) {
        echo "✗ Database connection failed: " . $e->getMessage() . "\n";
    }
} else {
    echo "⚠ Database config not found - cannot test connection\n";
}

echo "\n=== Verification Complete ===\n";
echo "If all items show ✓, your deployment is successful!\n";
?>
