# MPSC Quiz Portal - Deployment Instructions

## Overview
This package contains updates for the MPSC Quiz Portal with new JSON-based general-english data structure and improved quiz functionality.

## What's New
- ✅ JSON-based general-english question data (replaces old TXT files)
- ✅ Specific category display (shows "Grammar - Active Voice" instead of "General")
- ✅ Auto-advance quiz functionality (1-second delay after answer selection)
- ✅ Improved error handling and performance
- ✅ Mixed file format support (JSON for general-english, TXT for other categories)

## Files Included
- `quiz.php` - Updated quiz interface with auto-advance
- `functions.php` - Updated data loading functions for JSON/TXT support
- `database_migration.php` - Database schema updates
- `TestQnA/general-english/*.json` - New JSON question data files

## Deployment Steps

### 1. Backup Current System
```bash
# Backup your current files
cp quiz.php quiz.php.backup
cp includes/functions.php includes/functions.php.backup
tar -czf testqna_backup.tar.gz TestQnA/general-english/
```

### 2. Upload New Files
```bash
# Upload the new files to your server
# Replace the following files:
- quiz.php
- includes/functions.php

# Upload new directory structure:
- TestQnA/general-english/ (all JSON files)
```

### 3. Run Database Migration
```bash
# On your server, run the database migration:
php database_migration.php
```

### 4. Set Permissions
```bash
# Ensure proper permissions
chmod 644 quiz.php includes/functions.php
chmod 644 TestQnA/general-english/*.json
chmod +x database_migration.php
```

### 5. Test the System
1. Visit your quiz portal
2. Start a "Mixed English" quiz
3. Verify categories show specific names (e.g., "Vocabulary - Synonyms")
4. Verify auto-advance works (1-second delay after selecting answer)
5. Complete a full quiz to test database integration

## Rollback Instructions
If you need to rollback:
```bash
# Restore backup files
cp quiz.php.backup quiz.php
cp includes/functions.php.backup includes/functions.php
tar -xzf testqna_backup.tar.gz
```

## Support
- Check browser console for JavaScript errors
- Check PHP error logs for server-side issues
- Verify file permissions and paths
- Ensure database connection is working

## Technical Notes
- JSON files are loaded for general-english category only
- TXT files continue to work for general-knowledge and aptitude
- Database schema is backward compatible
- Auto-advance can be adjusted in quiz.php (setTimeout value)

